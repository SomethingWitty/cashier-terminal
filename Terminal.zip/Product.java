/*
 * Represents a certain pricing schema for a product as a tuple where a certain
 * quantity is mapped to a certain price
 * 
 */

public class Product
{
  private int quantity;
  private double price;
  private String productName;
  
  Product(String productName, int quantity, double price)
  {
    this.quantity = quantity;
    this.price = price;
    this.productName = productName;
  }
  public int getQuantity()
  {
    return quantity;
  }
  public double getPrice()
  {
    return price;
  }
  public String getName()
  {
    return productName;
  }
}